  ______   __                                   
 /      \ |  \                                  
|  $$$$$$\ \$$  ______   ______ ____    ______  
| $$___\$$|  \ /      \ |      \    \  |      \ 
 \$$    \ | $$|  $$$$$$\| $$$$$$\$$$$\  \$$$$$$\
 _\$$$$$$\| $$| $$  | $$| $$ | $$ | $$ /      $$
|  \__| $$| $$| $$__| $$| $$ | $$ | $$|  $$$$$$$
 \$$    $$| $$ \$$    $$| $$ | $$ | $$ \$$    $$
  \$$$$$$  \$$ _\$$$$$$$ \$$  \$$  \$$  \$$$$$$$
              |  \__| $$                        
               \$$    $$                        
                \$$$$$$                         

Creator: Dominik111
Built in: C++ and Assembly
Discord: Dominik111#7253
Recommended to run on Windows XP.
Made ONLY for educational purposes.
Safe version by N17Pro3426