Clutt-Virus version 2.0(Clutter-Destructive2.0)
-----------------

Creator: Clutter Tech
Created in: C #
Type: Trojan
Support OS: vista/win7/win8/win10

-----------------

My youtube channel: https://www.youtube.com/channel/UC9keh4wDjXFyiRhHDE_h90Q?view_as=subscriber
