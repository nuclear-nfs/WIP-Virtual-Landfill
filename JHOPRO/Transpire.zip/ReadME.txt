
 _____                         _                         
|_   _|                       (_)                        
  | |_ __ __ _ _ __  ___ _ __  _ _ __ ___   _____  _____ 
  | | '__/ _` | '_ \/ __| '_ \| | '__/ _ \ / _ \ \/ / _ \
  | | | | (_| | | | \__ \ |_) | | | |  __/|  __/>  <  __/
  \_/_|  \__,_|_| |_|___/ .__/|_|_|  \___(_)___/_/\_\___|
                        | |                              
                        |_|                              
--------------------------------------------------------------------------------
What is Transpire.exe?

Transpire.exe is a trojan that has 20 payloads, incluiding GDI-Effects and Bytebeats. This trojan
 was made in C++ and this is my 1st GDI-Trojan, it overwrites the bootsector (MBR) to a Pac-Man 
game (but this part is skidded, i'm sorry about that).
--------------------------------------------------------------------------------
Fun fact:

When it's on the final payload, Transpire starts to use 100% of CPU, it's a proposital payload, 
but it's very cool.
--------------------------------------------------------------------------------
Important!!!
You need to download "vcomp140d.dll" and place it at the same folder as Transpire is in to it to 
make it works. If you want to run it use a Virtual Machine (I recommend <b>Windows XP</b>) or a 
Sandbox. Remembering that i'm not responsible for any damages to your machine. This malware shows
flashing lights and loud sounds, so if you have a photosensitive disease like epilepsy, don't run
this or watch any video about it for your security. And yes, the MBR is skidded, but try to ignore
it, it's cool anyways...  
  
If you find some bug you can report it to my discord: ArTic202#1892
--------------------------------------------------------------------------------
What is the difference about TranspireDestructive and TranspireSafe?

As the name says, TranspireDestructive is the version that includes the destruction. Overwriting the
bootsector (MBR) to the Pac-Man Game. This version is recommended just for people that uses Virtual
Machine or a Sandbox.    
  
TranspireSafe is the version that doesn't have the destruction. So it won't overwrite the (MBR) and
you don't need to run it on a Virtual Machine or a Sandbox. Just choose your preference...
--------------------------------------------------------------------------------
How do I play the MBR game?

To control Pac-Man, use the keyboard arrows. If you have a 60% Size Keyboard and you don't have 
arrows. Just cry about it.
--------------------------------------------------------------------------------
Credits:

Rekto - Helped me a lot with GDI, thank you so much <3!  
Nanochess - Made the Pac-Man Bootsector game. (Original link: https://github.com/nanochess/pillman)  
Viznut - Made 2 bytebeats that i used in Transpire.exe  
And thanks to whoever is reading this :3  
--------------------------------------------------------------------------------
Transpire Showcase:

JhoPro (me) - https://www.youtube.com/watch?v=b7AlqWFoytU
