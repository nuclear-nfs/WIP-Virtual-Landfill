__________      .__               .__       ________     _______   
\______   \____ |  | _____ _______|__| _____\_____  \    \   _  \  
 |     ___/  _ \|  | \__  \\_  __ \  |/  ___//  ____/    /  /_\  \ 
 |    |  (  <_> )  |__/ __ \|  | \/  |\___ \/       \    \  \_/   \
 |____|   \____/|____(____  /__|  |__/____  >_______ \ /\ \_____  /
                          \/              \/        \/ \/       \/ 
_______________________________________________________________________

This software is not safe to run to your real machine because this soft-
ware is a malware or trojan that will destroy your computer and make it
unusable.

Programming Language: C++
Creator: GetMbr

This little trojan can show flashing lights, disortion effects, loud 
noises even this trojan can move your window renaming window title then
texts, spamming cursor effects and it can triggers BSOD after payloads 
by calling some 2 undocumented features: RtlAdjustPriviledge and
NtRaiseHardError.

WARNING: This malware is for educational purposes only and im not being
responsible to make a damage made to this computer.
